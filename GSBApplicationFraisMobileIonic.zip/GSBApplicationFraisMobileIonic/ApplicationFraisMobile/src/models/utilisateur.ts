export class Utilisateur{
      id: number;
      nomUtilisateur: string;
      motDePasse: string;
}