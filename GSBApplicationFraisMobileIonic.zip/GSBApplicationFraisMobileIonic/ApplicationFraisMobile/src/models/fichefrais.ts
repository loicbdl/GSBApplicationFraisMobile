import { Etat } from './etat';

export class FicheFrais{
      id: number;
      mois: string;
      annee: string;
      etat: Etat;
      montant: number;
}