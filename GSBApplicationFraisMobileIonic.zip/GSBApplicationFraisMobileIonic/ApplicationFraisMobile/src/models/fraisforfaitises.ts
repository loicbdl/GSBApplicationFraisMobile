export class FraisForfaitises {
      id: number;
      libelle: string;
      quantite: number;
      prix: number;
}