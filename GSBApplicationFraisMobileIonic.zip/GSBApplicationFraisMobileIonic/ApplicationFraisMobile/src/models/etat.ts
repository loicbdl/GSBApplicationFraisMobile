export class Etat{
      id: number;
      libelle: string;
}