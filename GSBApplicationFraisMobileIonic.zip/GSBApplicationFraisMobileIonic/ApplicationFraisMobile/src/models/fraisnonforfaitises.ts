export class FraisNonForfaitises {
      id: number;
      libelle: string;
      prix: number;
}